module.exports = [
"[project]/frontend2/.next-internal/server/app/dashboard/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend2__next-internal_server_app_dashboard_page_actions_46518fd1.js.map