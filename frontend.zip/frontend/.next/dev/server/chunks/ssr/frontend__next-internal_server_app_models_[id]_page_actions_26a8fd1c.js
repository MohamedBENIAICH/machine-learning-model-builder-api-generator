module.exports = [
"[project]/frontend/.next-internal/server/app/models/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend__next-internal_server_app_models_%5Bid%5D_page_actions_26a8fd1c.js.map