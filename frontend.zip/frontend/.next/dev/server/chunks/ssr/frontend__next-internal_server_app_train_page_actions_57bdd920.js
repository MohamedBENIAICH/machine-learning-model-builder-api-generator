module.exports = [
"[project]/frontend/.next-internal/server/app/train/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend__next-internal_server_app_train_page_actions_57bdd920.js.map