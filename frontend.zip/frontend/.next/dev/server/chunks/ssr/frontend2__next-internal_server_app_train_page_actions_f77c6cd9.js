module.exports = [
"[project]/frontend2/.next-internal/server/app/train/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend2__next-internal_server_app_train_page_actions_f77c6cd9.js.map