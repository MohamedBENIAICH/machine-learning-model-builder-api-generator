module.exports = [
"[project]/frontend2/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend2__next-internal_server_app_page_actions_e1546eff.js.map