(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_6ece0103._.js",
  "static/chunks/9e883_2e8ca402._.js"
],
    source: "dynamic"
});
