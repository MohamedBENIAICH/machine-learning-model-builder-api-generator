(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__62ca0473._.css",
  "static/chunks/17bbb_0eeffba0._.js"
],
    source: "dynamic"
});
