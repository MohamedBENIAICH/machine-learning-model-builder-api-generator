(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend2_30bdc8ac._.js",
  "static/chunks/17bbb_e6e6f4de._.js"
],
    source: "dynamic"
});
