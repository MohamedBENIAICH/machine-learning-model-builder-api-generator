(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_990f381e._.js",
  "static/chunks/9e883_368ba78a._.js"
],
    source: "dynamic"
});
