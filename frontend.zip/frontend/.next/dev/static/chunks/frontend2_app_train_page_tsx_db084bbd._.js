(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend2_f7be85d8._.js",
  "static/chunks/17bbb_d49699dc._.js"
],
    source: "dynamic"
});
