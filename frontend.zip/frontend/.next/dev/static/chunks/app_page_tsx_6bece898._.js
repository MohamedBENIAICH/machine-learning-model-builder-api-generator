(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_af11dc2c._.js",
  "static/chunks/_b2e9691e._.js"
],
    source: "dynamic"
});
