(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/17bbb_e051efe8._.js",
  "static/chunks/frontend2_c84d951e._.js"
],
    source: "dynamic"
});
