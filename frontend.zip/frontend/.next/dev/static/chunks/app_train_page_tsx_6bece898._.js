(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_c6deafd3._.js",
  "static/chunks/node_modules_aaf416e9._.js"
],
    source: "dynamic"
});
