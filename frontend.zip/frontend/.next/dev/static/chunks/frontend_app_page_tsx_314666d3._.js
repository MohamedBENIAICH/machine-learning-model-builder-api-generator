(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9e883_725df3d4._.js",
  "static/chunks/frontend_545a104a._.js"
],
    source: "dynamic"
});
