(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_0646de33._.js",
  "static/chunks/9e883_58fac463._.js"
],
    source: "dynamic"
});
