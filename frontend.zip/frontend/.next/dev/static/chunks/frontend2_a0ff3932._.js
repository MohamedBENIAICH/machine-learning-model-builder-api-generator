(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8cfb6d81._.js",
  "static/chunks/17bbb_next_dist_compiled_react-dom_98165d26._.js",
  "static/chunks/17bbb_next_dist_compiled_react-server-dom-turbopack_e091bc87._.js",
  "static/chunks/17bbb_next_dist_compiled_next-devtools_index_a5a992b7.js",
  "static/chunks/17bbb_next_dist_compiled_5e1f6602._.js",
  "static/chunks/17bbb_next_dist_client_2d403927._.js",
  "static/chunks/17bbb_next_dist_596fd23f._.js",
  "static/chunks/17bbb_@swc_helpers_cjs_99117983._.js"
],
    source: "entry"
});
