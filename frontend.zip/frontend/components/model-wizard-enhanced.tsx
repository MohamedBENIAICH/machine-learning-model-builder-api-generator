"use client"

import { useState, useMemo, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Check, ArrowRight, Upload, Zap, RotateCw, AlertCircle } from "lucide-react"
import Papa from "papaparse"
import { API_BASE_URL } from "@/lib/api"

type WizardStep = "name" | "type" | "upload" | "features" | "training" | "results"

interface TrainingResult {
  algorithm: string
  metrics: {
    [key: string]: number
  }
}

interface WizardState {
  name: string
  description: string
  modelType: "classification" | "regression"
  uploadedFile: File | null
  selectedFeatures: string[]
  allFeatures: string[]
  outputTarget?: string | null
  csvString?: string
  csvRows?: any[]
  trainingResults?: TrainingResult[]
  justification?: string
  bestModel?: string
}

interface ModelWizardEnhancedProps {
  onComplete?: (model: WizardState) => void
}

export function ModelWizardEnhanced({ onComplete }: ModelWizardEnhancedProps) {
  const router = useRouter()
  const [step, setStep] = useState<WizardStep>("name")
  const [state, setState] = useState<WizardState>({
    name: "",
    description: "",
    modelType: "classification",
    uploadedFile: null,
    selectedFeatures: [],
    allFeatures: [],
    outputTarget: null,
    csvString: undefined,
    csvRows: undefined,
    trainingResults: [],
    justification: "",
    bestModel: undefined,
  })
  const [isProcessing, setIsProcessing] = useState(false)
  const [searchInput, setSearchInput] = useState("")
  const [searchOutput, setSearchOutput] = useState("")
  const [error, setError] = useState<string | null>(null)

  const getDataType = (columnName: string): "numerical" | "categorical" => {
    const lowerName = columnName.toLowerCase()
    if (
      lowerName.includes("age") ||
      lowerName.includes("income") ||
      lowerName.includes("amount") ||
      lowerName.includes("rate") ||
      lowerName.includes("score") ||
      lowerName.includes("ratio") ||
      lowerName.includes("years") ||
      lowerName.includes("price") ||
      lowerName.includes("salary") ||
      lowerName.includes("value") ||
      lowerName.includes("num")
    ) {
      return "numerical"
    }
    return "categorical"
  }

  const toggleFeature = (feature: string) => {
    setState((prev) => {
      const has = prev.selectedFeatures.includes(feature)
      const nextSelected = has ? prev.selectedFeatures.filter((f) => f !== feature) : [...prev.selectedFeatures, feature]
      // if removing feature that is current output target, clear it
      const nextOutput = has && prev.outputTarget === feature ? null : prev.outputTarget
      return { ...prev, selectedFeatures: nextSelected, outputTarget: nextOutput }
    })
  }

  const filteredInputFeatures = useMemo(() => {
    const q = searchInput.trim().toLowerCase()
    return state.allFeatures.filter((c) => c !== state.outputTarget && c.toLowerCase().includes(q))
  }, [state.allFeatures, state.outputTarget, searchInput])

  const filteredOutputFeatures = useMemo(() => {
    const q = searchOutput.trim().toLowerCase()
    return state.allFeatures.filter((c) => c.toLowerCase().includes(q))
  }, [state.allFeatures, searchOutput])

  const steps: Array<{ id: WizardStep; label: string; number: number }> = [
    { id: "name", label: "Nom du modèle", number: 1 },
    { id: "type", label: "Type de modèle", number: 2 },
    { id: "upload", label: "Données d'entraînement", number: 3 },
    { id: "features", label: "Sélection des features", number: 4 },
    { id: "training", label: "Entraînement", number: 5 },
  ]

  const currentStepIndex = steps.findIndex((s) => s.id === step)
  const stepProgress = ((currentStepIndex + 1) / steps.length) * 100

  const handleNext = async () => {
    if (step === "name" && state.name.trim()) {
      setStep("type")
    } else if (step === "type") {
      setStep("upload")
    } else if (step === "upload" && state.allFeatures.length > 0) {
      setState((prev) => ({ ...prev, selectedFeatures: prev.selectedFeatures.length ? prev.selectedFeatures : prev.allFeatures }))
      setStep("features")
    } else if (step === "features" && state.selectedFeatures.length > 0 && state.outputTarget) {
      setStep("training")
    } else if (step === "training") {
      await handleComplete()
    } else if (step === "results") {
      router.push("/dashboard")
    }
  }

  const handleBack = () => {
    const stepIds: WizardStep[] = ["name", "type", "upload", "features", "training"]
    const currentIdx = stepIds.indexOf(step)
    if (currentIdx > 0) {
      setStep(stepIds[currentIdx - 1])
      setError(null)
    }
  }

  const canProceed =
    (step === "name" && state.name.trim()) ||
    step === "type" ||
    (step === "upload" && state.uploadedFile) ||
    (step === "features" && state.selectedFeatures.length > 0 && Boolean(state.outputTarget))

  const handleComplete = async () => {
    if (isProcessing) return
    setIsProcessing(true)
    setError(null)
    try {
      if (!state.csvString) throw new Error("No CSV data available. Please upload a CSV file.")
      if (!state.outputTarget) throw new Error("No output target selected.")

      const payload = {
        model_name: state.name,
        description: state.description,
        model_type: state.modelType,
        csv_data: state.csvString,
        input_features: state.selectedFeatures,
        output_feature: state.outputTarget,
      }

      console.log("🚀 Sending training request:", payload)

      const res = await fetch(`${API_BASE_URL}/train`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })

      const data = await res.json()
      console.log("✅ Training response:", data)

      if (!res.ok || !data.success) {
        const msg = data?.error || `Server returned status ${res.status}`
        throw new Error(msg)
      }

      setState((prev) => ({
        ...prev,
        trainingResults: data.results || [],
        justification: data.justification || "",
        bestModel: data.best_model || undefined,
      }))

      setStep("results")
    } catch (err: any) {
      console.error("❌ Error completing wizard:", err)
      setError(err?.message || String(err))
    } finally {
      setIsProcessing(false)
    }
  }

  // Auto-start training when entering the training step to improve UX
  useEffect(() => {
    if (step === "training") {
      // start training automatically
      void handleComplete()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step])

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/5 flex flex-col">
      {/* Header with progress */}
      <div className="border-b border-border/50 bg-card/50 backdrop-blur sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-lg font-bold text-foreground">Créer un nouveau modèle</h2>
              <span className="text-sm text-muted-foreground">
                Étape {currentStepIndex + 1} sur {steps.length}
              </span>
            </div>
            <Progress value={stepProgress} className="h-2" />
          </div>

          {/* Step indicators */}
          <div className="flex items-center justify-between gap-2">
            {steps.map((s, idx) => (
              <div key={s.id} className="flex-1 flex items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center font-semibold text-sm transition-all ${
                    idx <= currentStepIndex ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {idx < currentStepIndex ? <Check className="w-4 h-4" /> : s.number}
                </div>
                {idx < steps.length - 1 && (
                  <div
                    className={`flex-1 h-1 mx-1 rounded-full ${idx < currentStepIndex ? "bg-primary" : "bg-muted"}`}
                  ></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
        <div className="w-full max-w-2xl">
          {/* Step 1: Model Name */}
          {step === "name" && (
            <Card className="p-12 border border-border/50 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-8">
                <div className="space-y-2">
                  <h3 className="text-3xl font-bold text-foreground">Donnez un nom à votre modèle</h3>
                  <p className="text-muted-foreground">
                    Choisissez un nom descriptif pour identifier facilement votre modèle
                  </p>
                </div>

                <div className="space-y-4">
                  <input
                    type="text"
                    placeholder="Ex: Détection de fraude bancaire"
                    value={state.name}
                    onChange={(e) => setState((prev) => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground placeholder:text-muted-foreground text-lg"
                    autoFocus
                  />
                  <textarea
                    placeholder="Description optionnelle (ce que ce modèle fait, ses objectifs, etc.)"
                    value={state.description}
                    onChange={(e) => setState((prev) => ({ ...prev, description: e.target.value }))}
                    className="w-full px-4 py-3 bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary text-foreground placeholder:text-muted-foreground text-sm resize-none"
                    rows={3}
                  />
                </div>
              </div>
            </Card>
          )}

          {/* Step 2: Model Type */}
          {step === "type" && (
            <Card className="p-12 border border-border/50 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-8">
                <div className="space-y-2">
                  <h3 className="text-3xl font-bold text-foreground">Type de modèle</h3>
                  <p className="text-muted-foreground">Sélectionnez le type de problème que vous résolvez</p>
                </div>

                <div className="space-y-4">
                  <div
                    onClick={() => setState((prev) => ({ ...prev, modelType: "classification" }))}
                    className={`p-6 border-2 rounded-lg cursor-pointer transition-all ${
                      state.modelType === "classification"
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className={`w-6 h-6 rounded border-2 flex items-center justify-center mt-1 ${
                          state.modelType === "classification" ? "border-primary bg-primary" : "border-border"
                        }`}
                      >
                        {state.modelType === "classification" && <Check className="w-4 h-4 text-white" />}
                      </div>
                      <div>
                        <h4 className="font-bold text-foreground">Classification</h4>
                        <p className="text-sm text-muted-foreground mt-1">Prédire des catégories ou des étiquettes</p>
                        <p className="text-xs text-muted-foreground mt-2">Ex: Spam/Non-spam, Approuvé/Rejeté</p>
                      </div>
                    </div>
                  </div>

                  <div
                    onClick={() => setState((prev) => ({ ...prev, modelType: "regression" }))}
                    className={`p-6 border-2 rounded-lg cursor-pointer transition-all ${
                      state.modelType === "regression"
                        ? "border-primary bg-primary/10"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className={`w-6 h-6 rounded border-2 flex items-center justify-center mt-1 ${
                          state.modelType === "regression" ? "border-primary bg-primary" : "border-border"
                        }`}
                      >
                        {state.modelType === "regression" && <Check className="w-4 h-4 text-white" />}
                      </div>
                      <div>
                        <h4 className="font-bold text-foreground">Régression</h4>
                        <p className="text-sm text-muted-foreground mt-1">Prédire des valeurs numériques</p>
                        <p className="text-xs text-muted-foreground mt-2">Ex: Prix, température, revenus</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* Step 3: Data Upload */}
          {step === "upload" && (
            <Card className="p-12 border border-border/50 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-8">
                <div className="space-y-2">
                  <h3 className="text-3xl font-bold text-foreground">Données d'entraînement</h3>
                  <p className="text-muted-foreground">Importez votre fichier CSV ou Excel contenant les données</p>
                </div>

                <div
                  className="border-2 border-dashed border-primary/50 rounded-lg p-12 text-center hover:bg-primary/5 transition-colors cursor-pointer group"
                  onClick={() => document.getElementById("file-input")?.click()}
                >
                  <Upload className="w-12 h-12 text-primary/50 group-hover:text-primary mx-auto mb-4 transition-colors" />
                  <h4 className="font-bold text-foreground mb-2">
                    {state.uploadedFile ? state.uploadedFile.name : "Déposez vos fichiers ici"}
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    {state.uploadedFile
                      ? `Fichier prêt (${(state.uploadedFile.size / 1024).toFixed(2)} KB)`
                      : "Formats supportés: CSV, Excel"}
                  </p>
                      <input
                    id="file-input"
                    type="file"
                    accept=".csv,.xlsx,.xls"
                    onChange={(e) => {
                      const file = e.target.files?.[0]
                      if (!file) return
                      // Read file and parse CSV client-side, store CSV string for backend
                      setState((prev) => ({ ...prev, uploadedFile: file }))
                      if (file.name.toLowerCase().endsWith(".csv")) {
                        // Read file text
                        file.text()
                          .then((text) => {
                            try {
                              // Parse with header:true to get fields
                              const parsed = Papa.parse(text, {
                                header: true,
                                dynamicTyping: false,
                                skipEmptyLines: true,
                              })
                              const fields = (parsed.meta && parsed.meta.fields) || []
                              // Ensure fields are trimmed strings
                              const columns = fields.map((c: string) => String(c).trim())
                              setState((prev) => ({
                                ...prev,
                                allFeatures: columns,
                                selectedFeatures: columns.slice(),
                                outputTarget: columns[0] || null,
                                csvString: text,
                                csvRows: parsed.data || [],
                              }))
                            } catch (err) {
                              console.error("CSV parse error:", err)
                            }
                          })
                          .catch((err) => console.error("Error reading file:", err))
                      }
                    }}
                    className="hidden"
                  />
                </div>

                {state.uploadedFile && (
                  <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <div className="text-sm">
                      <p className="font-medium text-foreground">Fichier chargé avec succès</p>
                      <p className="text-muted-foreground text-xs mt-1">Prêt pour l'étape suivante</p>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          )}

          {/* Step 4: Feature Selection */}
          {step === "features" && (
            <Card className="p-8 border border-border/50 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-6">
                <div className="space-y-2">
                  <h3 className="text-3xl font-bold text-foreground">Sélection des features</h3>
                  <p className="text-muted-foreground">Choisissez les colonnes à utiliser pour l'entraînement</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Input Features (left) */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-foreground">Input Features</p>
                        <p className="text-sm text-muted-foreground">Select features that will predict your target</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <label className="inline-flex items-center text-sm cursor-pointer">
                          <input
                            type="checkbox"
                            checked={state.selectedFeatures.length === state.allFeatures.length && state.allFeatures.length > 0}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setState((prev) => ({ ...prev, selectedFeatures: prev.allFeatures.slice() }))
                              } else {
                                setState((prev) => ({ ...prev, selectedFeatures: [] }))
                              }
                            }}
                            className="mr-2"
                          />
                          Select All
                        </label>
                      </div>
                    </div>

                    <div className="relative">
                      <input
                        placeholder="Search features..."
                        onChange={(e) => setSearchInput(e.target.value)}
                        className="w-full px-3 py-2 bg-background/50 border border-border rounded-md focus:outline-none text-sm text-foreground"
                        aria-label="Search input features"
                      />
                    </div>

                    <div className="max-h-64 overflow-y-auto space-y-2 mt-2">
                      {filteredInputFeatures.map((feature) => {
                        const selected = state.selectedFeatures.includes(feature)
                        return (
                          <button
                            key={feature}
                            onClick={() => toggleFeature(feature)}
                            className={`w-full flex items-center justify-between p-3 border rounded-lg transition-transform text-left focus:outline-none ${
                              selected ? "border-primary bg-primary/8 shadow-[0_0_12px_rgba(99,102,241,0.08)]" : "border-border hover:border-primary/50"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div className={`w-4 h-4 rounded-sm border flex items-center justify-center ${selected ? "bg-primary border-primary" : "border-border"}`}>
                                {selected && <Check className="w-3 h-3 text-white" />}
                              </div>
                              <div>
                                <div className="text-sm font-medium text-foreground">{feature}</div>
                                <div className="text-xs text-muted-foreground">{getDataType(feature)}</div>
                              </div>
                            </div>
                            <div className="text-xs text-muted-foreground">{selected ? "Selected" : ""}</div>
                          </button>
                        )
                      })}
                      {filteredInputFeatures.length === 0 && <div className="text-sm text-muted-foreground">No features</div>}
                    </div>

                    <div className="bg-primary/5 border border-primary/20 rounded-lg p-3 mt-2">
                      <p className="text-sm text-foreground">
                        <strong>{state.selectedFeatures.length}</strong> of <strong>{state.allFeatures.length}</strong> features selected
                      </p>
                    </div>
                  </div>

                  {/* Output Target (right) */}
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium text-foreground">Output Target</p>
                      <p className="text-sm text-muted-foreground">Choose what your model will predict</p>
                    </div>

                    <div className="relative">
                      <input
                        placeholder="Search targets..."
                        onChange={(e) => setSearchOutput(e.target.value)}
                        className="w-full px-3 py-2 bg-background/50 border border-border rounded-md focus:outline-none text-sm text-foreground"
                        aria-label="Search output targets"
                      />
                    </div>

                    <div className="max-h-64 overflow-y-auto space-y-2 mt-2">
                      {filteredOutputFeatures.map((feature) => (
                        <label
                          key={feature}
                          className={`w-full flex items-center justify-between p-3 border rounded-lg cursor-pointer transition-colors ${
                            state.outputTarget === feature ? "border-blue-500 bg-blue-500/6 shadow-[0_0_12px_rgba(59,130,246,0.06)]" : "border-border hover:border-blue-400/40"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <input
                              type="radio"
                              name="output-target"
                              checked={state.outputTarget === feature}
                              onChange={() => setState((prev) => ({ ...prev, outputTarget: feature }))}
                              className="mr-2"
                              aria-label={`Set ${feature} as output target`}
                            />
                            <div>
                              <div className="text-sm font-medium text-foreground">{feature}</div>
                              <div className="text-xs text-muted-foreground">{getDataType(feature)}</div>
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">{state.outputTarget === feature ? "Selected" : ""}</div>
                        </label>
                      ))}
                      {filteredOutputFeatures.length === 0 && <div className="text-sm text-muted-foreground">No targets</div>}
                    </div>

                    <div className="bg-blue-500/5 border border-blue-500/20 rounded-lg p-3 mt-2">
                      <p className="text-sm text-foreground">Target: <strong>{state.outputTarget || "None"}</strong></p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          )}

          {/* Step 5: Training */}
          {step === "training" && (
            <Card className="p-12 border border-border/50 animate-in fade-in slide-in-from-bottom-4">
              <div className="space-y-8">
                <div className="space-y-2">
                  <h3 className="text-3xl font-bold text-foreground">Entraînement du modèle</h3>
                  <p className="text-muted-foreground">Votre modèle s'entraîne maintenant...</p>
                </div>

                {error && (
                  <Alert variant="destructive">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {/* Animated training visualization */}
                <div className="flex flex-col items-center justify-center py-12 space-y-6">
                  <div className="relative w-24 h-24">
                    {/* Animated circles */}
                    <div className="absolute inset-0 border-4 border-transparent border-t-primary rounded-full animate-spin"></div>
                    <div
                      className="absolute inset-2 border-4 border-transparent border-b-accent rounded-full animate-spin"
                      style={{ animationDirection: "reverse" }}
                    ></div>
                    <div className="absolute inset-4 flex items-center justify-center">
                      <Zap className="w-8 h-8 text-primary animate-pulse" />
                    </div>
                  </div>

                  <div className="text-center space-y-2">
                    <p className="text-lg font-semibold text-foreground">Entraînement en cours</p>
                    <p className="text-sm text-muted-foreground">Cela peut prendre quelques secondes...</p>
                  </div>
                </div>

                {/* Progress steps */}
                <div className="space-y-3">
                  {["Préprocessing des données", "Division train/test", "Entraînement du modèle", "Validation"].map(
                    (label, idx) => (
                      <div key={label} className="flex items-center gap-3">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                            idx < 2 ? "bg-green-500 text-white" : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {idx < 2 ? <Check className="w-4 h-4" /> : <span className="text-xs">{idx + 1}</span>}
                        </div>
                        <span className={idx < 2 ? "text-muted-foreground" : "text-foreground"}>{label}</span>
                      </div>
                    ),
                  )}
                </div>
              </div>
            </Card>
          )}

          {/* Results step */}
          {step === "results" && state.trainingResults && state.trainingResults.length > 0 && (
            <Card className="p-8 border border-green-200/50 bg-green-50/30 animate-in fade-in slide-in-from-bottom-4 space-y-6">
              {/* Success message */}
              <div className="flex items-center gap-3 p-4 rounded-lg bg-green-100/40 border border-green-200">
                <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center flex-shrink-0">
                  <Check className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="font-semibold text-green-900">Entraînement réussi!</p>
                  <p className="text-sm text-green-800">Le modèle a été entraîné avec succès. Voici les résultats:</p>
                </div>
              </div>

              {/* Best model highlight */}
              {state.bestModel && (
                <div className="p-4 rounded-lg border-2 border-accent bg-accent/5">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Meilleur modèle</p>
                  <p className="text-xl font-bold text-accent">{state.bestModel}</p>
                </div>
              )}

              {/* Metrics table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border/50">
                      <th className="text-left py-2 px-3 font-semibold">Algorithme</th>
                      <th className="text-right py-2 px-3 font-semibold">Métrique</th>
                      <th className="text-right py-2 px-3 font-semibold">Valeur</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.trainingResults.map((result, idx) => (
                      <tr
                        key={idx}
                        className={`border-b border-border/30 ${
                          result.algorithm === state.bestModel ? "bg-accent/5" : ""
                        }`}
                      >
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <span className="font-medium">{result.algorithm}</span>
                            {result.algorithm === state.bestModel && (
                              <Badge className="text-xs bg-accent text-accent-foreground">Meilleur</Badge>
                            )}
                          </div>
                        </td>
                        <td colSpan={2} className="py-3 px-3">
                          <div className="space-y-1">
                            {Object.entries(result.metrics).map(([metric, value]) => (
                              <div key={metric} className="flex justify-between gap-8">
                                <span className="text-muted-foreground">{metric}:</span>
                                <span className="font-semibold tabular-nums">
                                  {typeof value === "number" ? value.toFixed(4) : value}
                                </span>
                              </div>
                            ))}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Justification */}
              {state.justification && (
                <div className="p-4 rounded-lg border border-border/50 bg-muted/20">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Justification</p>
                  <p className="text-foreground leading-relaxed">{state.justification}</p>
                </div>
              )}

              {/* Error message if any */}
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </Card>
          )}

          {/* Navigation buttons */}
          {step !== "results" && (
            <div className="flex gap-4 mt-8 justify-between">
              <Button variant="outline" onClick={handleBack} disabled={step === "name"} className="gap-2 bg-transparent">
                Retour
              </Button>
              <Button onClick={handleNext} disabled={!canProceed || isProcessing} className="gap-2">
                {step === "training" ? "Terminer" : "Suivant"}
                {step !== "training" && <ArrowRight className="w-4 h-4" />}
              </Button>
            </div>
          )}

          {/* Results navigation buttons */}
          {step === "results" && (
            <div className="flex gap-4 mt-8 justify-between">
              <Button
                variant="outline"
                onClick={() => {
                  setState({
                    name: "",
                    description: "",
                    modelType: "classification",
                    uploadedFile: null,
                    selectedFeatures: [],
                    allFeatures: [],
                    outputTarget: null,
                    csvString: undefined,
                    csvRows: undefined,
                    trainingResults: [],
                    justification: "",
                    bestModel: undefined,
                  })
                  setStep("name")
                  setError(null)
                }}
                className="gap-2 bg-transparent"
              >
                <RotateCw className="w-4 h-4" />
                Nouveau modèle
              </Button>
              <Button onClick={() => router.push("/dashboard")} className="gap-2">
                Aller au tableau de bord
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
