"use client"

import { ModelWizardEnhanced } from "@/components/model-wizard-enhanced"

export default function TrainPage() {
  return <ModelWizardEnhanced />
}
